<?php
include 'upload-manager.php';
$t = '';
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit();
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Panou Administrator</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1 class="titlu-pagina">Panou Administrator</h1>
				<a href="index.php"><i class="fas fa-home"></i>Acasa</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Iesi</a>
			</div>
		</nav>
		<?= $success ?>
		<div class="content">
			<h2>Pagina principala</h2><br>
			<p class="welcome">Bine ai venit, <?=$_SESSION['name']?>! Scrie o postare:</p><br>
			<form action="home.php" method="post" id="" enctype="multipart/form-data">
				<?= $error1 ?>
				<input type="text" name="titlu" id="titlu" placeholder="Titlu"><br><br>
				<textarea name="shortDescription" id="" cols="50" rows="5" placeholder="Scurta descriere"></textarea><br><br>
				<input type="file" name="attachment" id="file" accept="application/pdf"><br><br>
				<input type="submit" name="submit" value="Upload" class="uploadpdf"><br><br>
			</form><?= $t ?>
		</div>
	</body>
</html>
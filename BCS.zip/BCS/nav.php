<?php

$nevbar = "<div class="navbar">
<div class="logo">
    <img src="images/white_logo.svg" alt="cartomanzia in live">
    <h2>Cartomanzia in Live</h2>
</div>
<ul class="taburi">
    <a class="tab" href="#home"><li>Acasa</li></a>
    <a class="tab" href="#news"><li>Notizie</li></a>
    <a class="tab" href="#contact"><li>Contattaci</li></a>
    <a class="tab" href="#about"><li>Su di noi</li></a>
    <a class="tab" href="#about"><li>Cartomanzia</li></a>
    <a class="tab" href="profile.php"><i class="fas fa-user-circle"></i>Profilo</a>
</ul>
<ul class="login">
    <div>
            <form class="loginn" action="authenticate.php" method="post">
                <label for="username">
                    <i class="fas fa-user"></i>
                </label>
                <input type="text" name="username" placeholder="Username" id="username" required>
                <label for="password">
                    <i class="fas fa-lock"></i>
                </label>
                <input type="password" name="password" placeholder="Password" id="password" required>
                <input type="submit" value="Entra">
            </form>
        </div>
    
</ul>
</div>;"
?>
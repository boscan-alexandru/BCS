<div class="navbar">
    <div class="logo">
        <img src="images/logo_white.png" alt="cartomanzia in live" height="50px" width="150px">
        <h2 class="logo-header">Cartomanzia in Live</h2>
    </div>
    <ul class="taburi">
        <a class="tab" href="index.html"><li>Acasa</li></a>
        <a class="tab" href="blog.html"><li>Blog</li></a>
        <a class="tab" href="#contact"><li>Contattaci</li></a>
        <a class="tab" href="inscrivitiperlavorare2.php"><li>Lavora con noi</li></a>
        <a class="tab" href="#about"><li>Cartomanzia</li></a>
        <a class="tab" href="profile.php"><i class="fas fa-user-circle"></i>Profilo</a>
    </ul>
    <ul class="login">
        <div>
            <form class="loginn" action="authenticate.php" method="post">
                <label for="username"><i class="fas fa-user"></i></label>
                <input type="text" name="username" placeholder="Username" id="username" required>
                <label for="password"><i class="fas fa-lock"></i></label>
                <input type="password" name="password" placeholder="Password" id="password" required>
                <input type="submit" value="Entra">
            </form>
        </div>
    </ul>
</div>
<?php
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = '';
$DATABASE_NAME = 'bcs';
$error1 = '';
$success = '';
$sufix = 'http://localhost:1234/BCS/';
$link = '';


// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_error() ) {
	// If there is an error with the connection, stop the script and display the error.
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());
}
//When Upload Button is clicked
if (isset($_POST['submit'])) {
	$titlu = $_POST['titlu'];
	$shortDesc = $_POST['shortDescription'];
	$targetFile = "upload/" . basename($_FILES['attachment']['name']);
	$extension = pathinfo($targetFile, PATHINFO_EXTENSION);
	$t = '';
	$var = 0;
	// Make sure the submitted registration values are not empty.
    if (!empty($titlu) && !empty($_POST['shortDescription']) && !empty($_FILES['attachment'] && $var !== 1)) {
		//upload the pdf into upload/
		
        move_uploaded_file($_FILES['attachment']['tmp_name'], $targetFile);
        $conn = new mysqli('localhost', 'root', '', 'bcs');
        $sql2 = $conn->query('SELECT * FROM content');

        while ($data = $sql2->fetch_array()){
            $t = $data['titlu'];
            $d = $data['shortDescription'];
            $link = $sufix . $data['PDF'];
        }
		$error1 = '';
		$var = 1;
		$sql = "INSERT INTO content (titlu, shortDescription, PDF)
				VALUES ('$titlu', '$shortDesc', '$targetFile');";
		if ($con->multi_query($sql) === TRUE) {
			$success = '<p class="success">Datele au fost introduse cu success!</p><br>';
		} else {
			echo "Error: " . $sql . "<br>" . $con->error;
		}
		$con->close();
    } else {
		$error1 = '<p class="red">Verifica campurile completate!</p><br>';
		$var = 0;
    }
}
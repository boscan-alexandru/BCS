<!DOCTYPE HTML>
<html>
	<head>
		<title>BCS - Despre</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="main.css"/>
	</head>
	<body id="top">
		<header>
			<nav class="container">
				<a href="index.php"><h1 id="logo">BCS</h1></a>
				<ul class="links">
					<a href="index.php"><li>Acasa</li></a>
					<a href="#"><li>Despre</li></a>
					<a href="cercetari.php"><li>Cercetari</li></a>
                    <a href="contact.php"><li>Contact</li></a>
                    <a href="carti.php"><li>Carti</li></a>
				</ul>
			</nav>
        </header>
<!-- content -->
        <div id="main">

        </div>
<!-- Footer -->
		<footer id="footer">
			<div class="inner">
				<h2>Who I am</h2>
				<p>I'm a full stack Web Developer, in my free time I create designs for websites, I did freelance work for the last 6 years for various people and companies.
                    I have god knoleage of HTML, CSS, JAVASCRIPT, PHP, MySQL, BOOTSTRAP, VUE.JS, REACT.JS. Contact me if interested to work together.
                </p>
			</div>
		</footer>

<!-- Scripts -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery.poptrox.min.js"></script>
	<script src="assets/js/skel.min.js"></script>
	<script src="assets/js/util.js"></script>
	<script src="assets/js/main.js"></script>

	</body>
</html>